<!DOCTYPE html>

<?php
	$conn = new mysqli("localhost", "root", "", "fspproject");
	if ($conn->connect_errno) {
    	die("Failed to connect to MySQL: " . $conn->connect_error);
	}
?>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Temp Main Admin Team Display</title>
</head>
<body>

<?php //TABLE DISPLAY
	//FUNCTIONS
	function querry($conn, $sql, $params = [], $param_types = ''){
		$stmt = $conn->prepare($sql);
		if ($params) {
        	$stmt->bind_param($param_types, ...$params);
    	}
		$stmt->execute();
		$res = $stmt->get_result();
		$stmt->close();
		return $res;
	}


	//TEAM	
	echo "<table border='1'>
	<tr>
		<th colspan=3>Team</th>
		<th> <a href=teamDisplay.php?action=add> Tambah Data </a> </th>
	</tr>
	<tr> 
		<th>Game</th> 
		<th>Name</th> 
		<th colspan=2>Aksi</th>
	</tr>";

	$teams = querry($conn, "SELECT * from team"); //SELECT ALL FROM TEAM
	while($teamRow = $teams->fetch_assoc()) {
	echo "<tr>";

		$idGame = $teamRow['idgame'];
		$sql = "SELECT game.name from game inner join team on team.idgame = game.idgame where team.idgame=?"; 
		$gameNames = querry($conn, $sql, [$idGame], 'i'); //SHOW GAME NAMES INSTEAD OF ID
		while($gameRow = $gameNames->fetch_assoc()) {
			echo "<td>".htmlspecialchars($gameRow['name'])."</td>" ;
			break;
		}

		echo "<td>". $teamRow['name']. "</td>";

		//Redirect to update or delete
		echo "<td> <a href=teamDisplay.php?action=edit&idteam=".htmlspecialchars($teamRow['idteam'])."> Ubah Data </a> </td>";
		echo "<td> <a href=deleteProcess.php?idteam=".htmlspecialchars($teamRow['idteam'])."> Hapus Data </a> </td>";
		echo "</tr>";
	}
	echo "</table>" ;

	/* close connection */
	//$conn->close(); 
?>
<br>


<div>
	<?php //Real messy code ik, might simplify later i don't want em all in one place >:(
		$editName;
		$editIDGame;

		if(isset($_GET["action"])){
			echo "<form action='insertEditProcess.php' method='POST' enctype='multipart/form-data'>";
			
			if($_GET["action"] == "add"){
				echo "<label>ADD TEAM TO TABLE</label>";
			} else{
				echo "<label>EDIT SELECTED TEAM</label>";
				echo "<input type='hidden' name='idteam' value='".$_GET['idteam']."'>"; //ID TEAM

				$sql = "SELECT * from team where team.idteam=?"; 
				$editedTeam = querry($conn, $sql, [$_GET['idteam']], 'i');

				while($edited = $editedTeam->fetch_assoc()) {
					$editName = htmlspecialchars($edited["name"]);
					$editIDGame = htmlspecialchars($edited["idgame"]);
				}
			}
					
			echo "<input type='hidden' name='inputTable' value='team'>"; //IDENTIFIER

			echo "<p><label>Game: </label>";
			$gameQuerry = querry($conn, "SELECT * from game"); //SHOW GAME NAMES
			echo "<select name=game>";

			while ($games=$gameQuerry->fetch_assoc()) {
				if($editIDGame == htmlspecialchars($games['idgame'])){
					echo "<option value=".htmlspecialchars($games['idgame'])." selected>".htmlspecialchars($games['name'])."</option>";
				} else{
					echo "<option value=".htmlspecialchars($games['idgame']).">".htmlspecialchars($games['name'])."</option>";
				}	
			}
			echo "</select></p>";
			
			if($_GET["action"] == "add"){
				echo "<p><label>Team Name:</label> <input type='text' name='name'>";
			} else{
				echo "<p><label>Team Name:</label> <input type='text' name='name' value=".$editName.">";
			}
			
			echo "<button type='submit'>Save</button></p>
			</form>";

		}
	?>
</div>


</body>
</html>