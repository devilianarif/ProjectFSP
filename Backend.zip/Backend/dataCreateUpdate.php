<!DOCTYPE html>

<?php
	$conn = new mysqli("localhost", "root", "", "fspproject");
	if ($conn->connect_errno) {
    	die("Failed to connect to MySQL: " . $conn->connect_error);
	}
?>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<?php

	function querry($conn, $sql, $params = [], $param_types = ''){
		$stmt = $conn->prepare($sql);
		if ($params) {
        	$stmt->bind_param($param_types, ...$params);
    	}
		$stmt->execute();
		$res = $stmt->get_result();
		$stmt->close();
		return $res;
	}


	if(isset($_GET['hasil'])){
			if($_GET['hasil']){
				echo "<p>Data berhasil disimpan</p>";
			} else {
				echo "<p>Data gagal disimpan</p>";
			}
		}
	?>

	<form action="insertProcess.php" method="POST" enctype="multipart/form-data">
		<input type="hidden" name="inputTable" value="team">

		<label>Game: </label>
		<?php
			$gameQuerry = querry($conn, "SELECT * from game"); //SHOW GAME NAMES
			echo "<select name=game>";
			while ($games=$gameQuerry->fetch_assoc()) {
				echo "<option value=".htmlspecialchars($games['idgame']).">".htmlspecialchars($games['name'])."</option>";
			}
			echo "</select>";
		?>
		<br>
		<label>Team Name:</label> <input type="text" name="name">
		<button type="submit">Save</button>
	</form>
</body>
</html>