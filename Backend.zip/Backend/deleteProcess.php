<?php //Connection & Function
	$conn = new mysqli("localhost", "root", "", "fspproject");
	if ($conn->connect_errno) {
    	die("Failed to connect to MySQL: " . $conn->connect_error);
	}

	function querry($conn, $sql, $params = [], $param_types = ''){
		$stmt = $conn->prepare($sql);
		if ($params) {
        	$stmt->bind_param($param_types, ...$params);
    	}
		$stmt->execute();
		$res = $stmt->get_result();
		$stmt->close();
		return $res;
	}
?>

<?php
	if (isset($_GET['idteam'])) {
    	$sql = "DELETE FROM team WHERE team.idteam = ?";
    	querry($conn, $sql, [$_GET['idteam']], 'i');
	}

	header("Location: teamDisplay.php"); //SEND EM BACK
?>