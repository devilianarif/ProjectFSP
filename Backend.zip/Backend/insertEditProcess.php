<?php //Connection & Function
	$conn = new mysqli("localhost", "root", "", "fspproject");
	if ($conn->connect_errno) {
    	die("Failed to connect to MySQL: " . $conn->connect_error);
	}

	function querry($conn, $sql, $params = [], $param_types = ''){
		$stmt = $conn->prepare($sql);
		if ($params) {
        	$stmt->bind_param($param_types, ...$params);
    	}
		$stmt->execute();
		$res = $stmt->get_result();
		$stmt->close();
		return $res;
	}
?>

<?php
	//Check if which table isset
	if (isset($_POST['inputTable'])) {
    	$inputTable = $_POST['inputTable'];
	} else {
    	echo "inputTable is not set.";
	}


	//TEAM
	if($inputTable == "team"){
		if(isset($_POST['idteam'])){ //UPDATE
			$sql = "UPDATE team SET idgame=?, name=? WHERE team.idteam=?;";
			querry($conn, $sql, [$_POST['game'], $_POST['name'], $_POST['idteam']], "isi");
		} else { //CREATE
			$sql = "INSERT INTO team (idgame, name) VALUES (?, ?);";
			querry($conn, $sql, [$_POST['game'], $_POST['name']], "is");
		}
		header("Location: teamDisplay.php"); //SEND EM BACK
	}

	
?>