<?php //Connection & Function
	$conn = new mysqli("localhost", "root", "", "fspproject");
	if ($conn->connect_errno) {
    	die("Failed to connect to MySQL: " . $conn->connect_error);
	}

	function querry($conn, $sql, $params = [], $param_types = ''){
		$stmt = $conn->prepare($sql);
		if ($params) {
        	$stmt->bind_param($param_types, ...$params);
    	}
		$stmt->execute();
		$res = $stmt->get_result();
		$stmt->close();
		return $res;
	}
?>

<?php
	//Check if which table isset
	if (isset($_POST['inputTable'])) {
    	$inputTable = $_POST['inputTable'];
	} else {
    	echo "inputTable is not set.";
	}


	//TEAM
	if($inputTable == "team"){
		if(isset($_POST['idteam'])){ //UPDATE
			$sql = "UPDATE team SET idgame=?, name=? WHERE team.idteam=?;";
			querry($conn, $sql, [$_POST['game'], $_POST['name'], $_POST['idteam']], "isi");
		} else { //CREATE
			$sql = "INSERT INTO team (idgame, name) VALUES (?, ?);";
			querry($conn, $sql, [$_POST['game'], $_POST['name']], "is");
		}
		header("Location: teamDisplay.php"); //SEND EM BACK

	//GAME
	} else if($inputTable == "game"){
		if(isset($_POST['idgame'])){ //UPDATE
			$sql = "UPDATE game SET name=?, description=? WHERE game.idgame=?;";
			querry($conn, $sql, [$_POST['name'], $_POST['desc'], $_POST['idgame']], "ssi");
		} else { //CREATE
			$sql = "INSERT INTO game (name, description) VALUES (?, ?);";
			querry($conn, $sql, [$_POST['name'], $_POST['desc']], "ss");
		}
		header("Location: gameDisplay.php"); //SEND EM BACK

	//MEMBER
	} else if($inputTable == "member"){
		if(isset($_POST['idmember']) && isset($_POST['idteam'])){ //UPDATE
			$sql = "UPDATE team_members SET description=? WHERE team_members.idmember=? AND team_members.idteam=?;";
			querry($conn, $sql, [$_POST['desc'], $_POST['idmember'], $_POST['idteam']], "sii");
			header("Location: memberDisplay.php?idteam=".$_POST['idteam']); //SEND EM BACK
		} /*else { //CREATE
			$sql = "INSERT INTO game (name, description) VALUES (?, ?);";
			querry($conn, $sql, [$_POST['name'], $_POST['desc']], "ss");
			header("Location: memberDisplay.php"); //SEND EM BACK
		} */ //CREATE NANTI DARI JOIN PROPOSAL JANGAN LUPA GANTI COPAS DARI GAME

	//ACHIEVEMENT
	} else if($inputTable == "achievement"){
		if(isset($_POST['idachv'])){ //UPDATE
			$sql = "UPDATE achievement SET idteam=?, name=?, date =?, description=? WHERE achievement.idachievement=?;";
			querry($conn, $sql, [$_POST['team'], $_POST['name'], $_POST['date'], $_POST['desc'], $_POST['idachv']], "isssi");
		} else { //CREATE
			$sql = "INSERT INTO achievement (idteam, name, date, description) VALUES (?,?,?,?);";
			querry($conn, $sql, [$_POST['team'], $_POST['name'], $_POST['date'], $_POST['desc']], "isss");
		}
		header("Location: achievementDisplay.php"); //SEND EM BACK

	//EVENTLIST
	} else if($inputTable == "eventList"){
		if(isset($_POST['idevent'])){ //UPDATE
			$sql = "UPDATE event SET name=?, date=?, description=? WHERE event.idevent=?;";
			querry($conn, $sql, [$_POST['name'], $_POST['date'], $_POST['desc'], $_POST['idevent']], "sssi");
		} else { //CREATE
			$sql = "INSERT INTO event (name, date, description) VALUES (?,?,?);";
			querry($conn, $sql, [$_POST['name'], $_POST['date'], $_POST['desc']], "sss");
		}
		header("Location: eventListDisplay.php"); //SEND EM BACK

	//EVENT PARTICIPANT 
	} else if($inputTable == "eventParticipant"){
		if(isset($_POST['idevent']) && isset($_POST['idteam'])){ //UPDATE (UNUSED)
			$sql = "UPDATE event_teams SET idteam=?  WHERE event_teams.idevent=?; ";
			querry($conn, $sql, [$_POST['idteam'], $_POST['idevent']], "ii");
		} else { //CREATE
			$sql = "INSERT INTO event_teams (idevent, idteam) VALUES (?,?);";
			querry($conn, $sql, [$_POST['idevent'], $_POST['team']], "ii");
		}
		header("Location: eventDisplay.php?idevent=".$_POST['idevent']); //SEND EM BACK

	}
	
?>